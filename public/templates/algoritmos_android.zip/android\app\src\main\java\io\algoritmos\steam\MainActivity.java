package io.algoritmos.steam;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
