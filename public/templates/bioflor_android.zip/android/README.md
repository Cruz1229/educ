# BioFlor: proyecto Android

1. Extrae el ZIP de la descarga. Dentro de la carpeta del juego encontrarás otro ZIP terminado en _android.zip; extráelo también.
2. En Android Studio selecciona Open y abre la carpeta android que contiene settings.gradle y gradlew.bat.
3. Usa JDK 21 y Android SDK 36. Android Studio puede instalar el SDK desde SDK Manager. La primera sincronización necesita Internet para descargar Gradle y las bibliotecas de Google/Maven.
4. Espera a que termine la sincronización de Gradle, selecciona un teléfono o emulador con Android 7.0 (API 24) o posterior y pulsa Run.

## Compilar desde Windows

Desde esta carpeta android, con JAVA_HOME apuntando al JDK 21 y ANDROID_HOME al SDK:

    .\gradlew.bat assembleDebug

La APK de prueba queda en app/build/outputs/apk/debug/app-debug.apk.
En macOS/Linux ejecuta chmod +x gradlew y ./gradlew assembleDebug.
Si Gradle no encuentra el SDK, configura sdk.dir en un archivo local.properties con la ruta del SDK de tu equipo (puedes usar barras /).

## Contenido y personalización

La carpeta vendor incluye los módulos Android de Capacitor y sus licencias. No necesitas npm, node_modules ni otras carpetas del equipo donde se creó la plantilla.
El juego web ya está compilado en app/src/main/assets/public. Su configuración está en app/src/main/assets/public/config/bioflor-config.json; se conserva al compilar Android.
Este paquete contiene el proyecto Android y los recursos web compilados. Los fuentes React se mantienen en el proyecto móvil original. Para actualizar el juego, reemplaza los recursos de public con una nueva compilación y vuelve a compilar Android.
Las versiones de las dependencias incluidas están en vendor/versions.json. Estos módulos se usan directamente desde Gradle; no ejecutes cap sync sobre este paquete independiente.
